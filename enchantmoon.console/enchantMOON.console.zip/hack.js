importJS(["lib/socket.io.js"], function() {

function connect(id) {
    var socket = io.connect('http://enchantmoonconsole.herokuapp.com:80?host='+id, {'transports': ["xhr-polling"]});
    socket.on("command", function(command) {
        var r = null;
        try{
            r = eval(command);
        } catch(e){
            r = e.toString();
        };
        
        try{
            socket.emit("proceed", r);
        } catch(e){
            socket.emit("proceed", e.toString());
        }
    });
};

var sticker = Sticker.create();

sticker.ontap = function() {
	var id = window.prompt("Enter ID:", window.localStorage['id'] || "");
    if(id){
        window.localStorage['id'] = id;
    }
    connect(id);
};

sticker.register();

});
